<?php $__env->startSection('title'); ?>
Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Create New Product</a>
<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Description</th>
        <th scope="col">Stock</th>
        <th scope="col">Price</th>
        <th scope="col">Created At</th>
        <th scope="col">Updated At</th>
        <th scope="col">Actions</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e(++$i); ?></th>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->description); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td><?php echo e($product->price); ?></td>
                <td><?php echo e($product->created_at); ?></td>
                <td><?php echo e($product->updated_at); ?></td>
                <td>
                    <a href="<?php echo e('/products/show/'.$product->id); ?>" class="btn btn-outline-primary">View</a>
                    <a href="<?php echo e('/products/update/'.$product->id); ?>" class="btn btn-outline-warning">Edit</a>
                    <a href="<?php echo e(route('product.delete', $product->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-outline-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php if($products instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
    <?php echo e($products->links()); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kimleang/Desktop/laravel-projs/mini-project/resources/views/products/search.blade.php ENDPATH**/ ?>