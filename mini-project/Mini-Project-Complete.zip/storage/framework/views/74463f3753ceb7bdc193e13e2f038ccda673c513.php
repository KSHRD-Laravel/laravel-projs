<?php $__env->startSection('title'); ?>
Product Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="width: 18rem;">
    <img class="card-img-top" src="<?php echo e(url("storage/products/$product->image")); ?>" alt="Card image cap">
    <div class="card-body">
        <h3 class="card-title"><?php echo e($product->name); ?></h3>
        <p class="card-text"><?php echo e($product->description); ?></p>

        <p id="created_at"><?php echo e($product->created_at); ?></p>
        <p id="updated_at"><?php echo e($product->updated_at); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
    let created = document.getElementById('created_at')
    created.innerText = moment(created.innerText).fromNow();

    let updated_at = document.getElementById('updated_at')
    updated_at.innerText = moment(updated_at.innerText).fromNow();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kimleang/Desktop/laravel-projs/mini-project/resources/views/products/show.blade.php ENDPATH**/ ?>