<?php $__env->startSection('title'); ?>
Create Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/products/edit/'.$product->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Name</label>
    <input value="<?php echo e($product->name); ?>" name="name" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter product name">

    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Description</label>
        <input value="<?php echo e($product->description); ?>" name="description" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter product description">

      </div>

      <div class="form-group">
        <label for="exampleInputEmail1">Stock</label>
        <input value="<?php echo e($product->stock); ?>" name="stock" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter product stock">

      </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Price</label>
        <input value="<?php echo e($product->price); ?>" name="price" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter product price">

    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kimleang/Desktop/laravel-projs/mini-project/resources/views/products/edit.blade.php ENDPATH**/ ?>